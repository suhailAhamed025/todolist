
const userCardTemplate = document.querySelector("[data-user-template]")  
const userCardContainer = document.querySelector("[data-user-cards-container]")
const searchInput = document.querySelector("[data-search]")

let users=[]
    
userCardContainer.addEventListener("click",i =>{ 

    let clickVal = i.target.parentElement.parentElement.firstElementChild.innerHTML
    console.log(clickVal) //to get id of element on clicking 
    
    let child=userCardContainer.children //accessing cards
        
    for (let i = 0; i < child.length; i++) {
        let element = userCardContainer.children[i].children[0].innerHTML  //accessing id "ex:1"

        if (clickVal==element) {
            userCardContainer.removeChild(child[clickVal-1])
            
        }
        
       
    }
}) 



searchInput.addEventListener("input",e=>{
    const value =e.target.value.toLowerCase()
   
    
    users.forEach(user => {

      console.log(user.id);
        if (user.title.toLowerCase().indexOf(value)>-1) {
                        user.element.style.display=""
                    }
                    else{
                        user.element.style.display="none"
                    }
    });
})

fetch("https://jsonplaceholder.typicode.com/todos")
.then(res => res.json())
  .then(data => {
      users = data.map(user => {
      const card = userCardTemplate.content.cloneNode(true).children[0]
      const header = card.querySelector("[data-header]")
      const body = card.querySelector("[data-body]")
      header.textContent = user.id
      body.textContent = user.title
      userCardContainer.append(card)
      return { id: user.id, title: user.title, element: card }
    })
})
    