let divClass= document.querySelectorAll(".changeColor")
console.log(divClass);



for(let i=0;i<=3;i++){
    if(i%2==0){
        divClass[i].style.color="red"
    }
    else{
        divClass[i].style.color="black"
    }
}

let name="My name is suhail"

let rev=Array.from(name)
console.log(rev);

rev.forEach(element => {


    
});

// let promise= new Promise()

// promise(resolve,reject, e=>{
//     fetch("https://jsonplaceholder.typicode.com/todos")
//     .then(response=>response.json)
//     .then(console.log(response))
// })

