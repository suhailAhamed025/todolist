var addButton= document.querySelector("#push")
var inputVal= document.querySelector('#newtask input') 



addButton.addEventListener('click',e=>{
    if(inputVal.value.lenght==0){
        
        alert("Enter a task")
    }
    
    else{
        document.querySelector("#tasks").innerHTML +=`
                <tr>
                    <td></td>
                    
                    <td id="addTask" class="myTask">${inputVal.value} </td>
                    <td> 
                        <input type="button" value="done" class="taskDone">
                        <button class="deleteTask"><i class="bi bi-trash"></i></button>
                        <button class="editTask" data-toggle="modal" data-target="#exampleModal">
                        <i class="bi bi-pencil-fill"></i>
                        </button>
                    </td>    
                </tr>` 
    }
    var deleteTask = document.querySelectorAll(".deleteTask")

    for(let i=0; i<deleteTask.length; i++){
        deleteTask[i].addEventListener('click', e=>{
            // console.log(i);
            deleteTask[i].parentNode.parentNode.remove();
        })
    }


    let taskDone = document.querySelectorAll(".taskDone")
    for(let i=0; i<taskDone.length; i++){
        taskDone[i].addEventListener("click",e=>{
        
        if (e.target.parentElement.previousElementSibling.className==="myTask") {
           
            e.target.parentElement.previousElementSibling.classList.toggle('checked');

            
        }
        
    },false)


    }



    
})